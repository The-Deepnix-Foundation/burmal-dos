# Тестирование BURMAL-DOS

## 1. Быстрый тест в QEMU (рекомендуется перед записью на флешку)

Установите QEMU на вашей машине:

```bash
# Debian/Ubuntu (хост для тестирования, не для сборки!)
sudo apt install qemu-system-x86

# macOS
brew install qemu

# Windows
# Скачайте QEMU: https://www.qemu.org/download/#windows
```

Запуск (BIOS-режим):

```bash
qemu-system-x86_64 -m 2048 -cdrom out/BURMAL-DOS.iso -boot d
```

Запуск в UEFI-режиме (нужен OVMF):

```bash
# Debian/Ubuntu: sudo apt install ovmf
qemu-system-x86_64 -m 2048 -bios /usr/share/OVMF/OVMF_CODE.fd \
    -cdrom out/BURMAL-DOS.iso -boot d
```

Если всё собралось верно, вы должны увидеть зелёный баннер
`Добро пожаловать в BURMAL-DOS!` и меню (установить / live-консоль).

## 2. Запись на флешку

### Через Rufus (Windows)
1. Откройте Rufus, выберите флешку.
2. В поле "Boot selection" укажите `BURMAL-DOS.iso`.
3. Режим записи — **DD Image** (это важно: ISO гибридный, режим ISO/DD
   переключится автоматически при обнаружении гибридного образа).
4. Нажмите "Start".

### Через Ventoy (Windows/Linux/macOS)
1. Установите Ventoy на флешку один раз: https://www.ventoy.net
2. Просто скопируйте `BURMAL-DOS.iso` на флешку как обычный файл.
3. При загрузке с флешки выберите файл ISO в меню Ventoy.

### Через dd (Linux/macOS)
```bash
sudo dd if=out/BURMAL-DOS.iso of=/dev/sdX bs=4M status=progress conv=fsync
# ЗАМЕНИТЕ /dev/sdX на реальное устройство флешки! Это стирает всё на ней.
```

## 3. Проверка в виртуальной машине (VirtualBox / VMware)

- Тип ОС: Linux → Other Linux (64-bit)
- Загрузка: сначала попробуйте BIOS-режим (проще всего заводится),
  затем UEFI, если нужно проверить именно его.
- Память: минимум 1–2 ГБ, диск: минимум 4–8 ГБ для установки.

## xorriso: "Failed to open device (a pseudo-drive): Permission denied"

Сборка доходит до самого конца (ядро, пакеты, apkovl, syslinux, grub —
всё готово), и падает на записи `.iso`:

```
libburn : SORRY : Failed to open device (a pseudo-drive) : Permission denied
libburn : FATAL : Burn run failed
```

`xorriso` открывает выходной файл особым образом («псевдо-устройство»),
и на bind-mount томе Docker это может не сработать. В `build-iso.sh`
это уже обойдено: ISO пишется во внутреннюю папку контейнера
(`~/iso-build-out`), а в примонтированный `/output` готовый файл
копируется обычным `cp`. Если ошибка всё же возникает — проверьте
права на `out/` на хосте (`chmod 777 out`).

## Сборка "висит" 30+ минут на шаге kernel

Сначала проверьте, не работают ли параллельно контейнеры от прошлых
прерванных попыток:

```bash
docker stats
```

`Ctrl+C` останавливает только терминал-клиент — сам контейнер остаётся
работать в демоне и продолжает качать пакеты. Несколько таких
«призраков» делят сеть и диск, и сборка кажется зависшей. Почистить:

```bash
docker ps -q | xargs -r docker kill
docker ps -a -q | xargs -r docker rm -f
```

Для сравнения: на чистом запуске шаг сборки ядра/modloop занимает
меньше минуты, и в выводе сразу видно прогресс-бар `mksquashfs`.

## Сборка прошла без ошибок, но `out/` пустой

Это конкретный известный сценарий: `mkimage.sh` печатает `Images
generated in /output`, выходит с кодом 0, но никакого `.iso` там нет.
Причина — внутренняя проверка `mkimage.sh` `list_has "$ARCH" $arch`
(поддерживает ли профиль запрошенную архитектуру) не проходит, и сборка
профиля молча пропускается ещё до сборки самого образа.

Как проверить и починить:

1. **Соберите заново и сохраните ПОЛНЫЙ лог** (не `tail -50`, а весь файл):
   ```bash
   docker rmi burmal-dos-build:latest 2>/dev/null
   ./build/docker-build.sh > build_log.txt 2>&1
   grep -n '\[burmal\]' build_log.txt
   ```
   Строка `[burmal] profile resolved: arch='...' ...` — это диагностика,
   которую печатает сам `mkimg.burmal.sh`. Если там `arch='x86_64'` —
   значит наш профиль всё сделал правильно, и проблема глубже, в самом
   `mkimage.sh`/окружении сборки (см. пункт 3). Если `arch` там пустой,
   не `x86_64`, или строки вообще нет — значит профиль не был найден/не
   выполнился, проверьте, что `--profile burmal` совпадает с именем
   функции `profile_burmal` в `mkimg.burmal.sh`.

2. **Apple Silicon (Mac M1/M2/M3/M4):** Docker по умолчанию может
   собирать образы под `arm64`, и тогда сборка `x86_64`-ISO тихо
   ничего не даст. В `build/docker-build.sh` уже добавлен
   `--platform linux/amd64` на оба вызова (`docker build` и
   `docker run`) — обновите файл из этого архива и запустите заново.

3. **Проверьте, что вообще работает "чистый" официальный профиль**,
   без наших надстроек — это отделяет проблему окружения от проблемы
   в `mkimg.burmal.sh`:
   ```bash
   docker run --rm --platform linux/amd64 -v "$PWD/out:/output" \
       --entrypoint sh burmal-dos-build -c \
       'sh "$APORTS_DIR"/scripts/mkimage.sh --tag v3.23 --outdir /output \
            --arch x86_64 \
            --repository https://dl-cdn.alpinelinux.org/alpine/v3.23/main \
            --profile standard'
   ```
   Если это тоже не создаёт `.iso` — проблема не в BURMAL-DOS, а в
   версии `mkimage.sh`/окружении сборки; сверьтесь с
   https://wiki.alpinelinux.org/wiki/How_to_make_a_custom_ISO_image_with_mkimage
   Если стандартный профиль отрабатывает нормально, а `burmal` — нет,
   пришлите мне полный `build_log.txt` и строку `[burmal] profile
   resolved: ...` из него — разберём точечно.

## Если что-то не грузится

1. Проверьте, что сборка вообще завершилась без ошибок —
   смотрите вывод `docker-build.sh` / `build-iso.sh` целиком, не только
   последнюю строку.
2. Проверьте, что `out/*.iso` действительно не пустой:
   `ls -la out/ && file out/*.iso`.
3. Попробуйте сначала собрать **чистый официальный** профиль
   (`--profile standard` вместо `--profile burmal`) — если он тоже не
   грузится, проблема в окружении сборки (Docker/QEMU), а не в
   BURMAL-DOS. Если стандартный профиль грузится, а `burmal` — нет,
   проблема где-то в `mkimg.burmal.sh` / `genapkovl-burmal.sh` —
   сверьте их с актуальными файлами в
   https://gitlab.alpinelinux.org/alpine/aports (`scripts/mkimg.standard.sh`,
   `scripts/genapkovl-dhcp.sh`) — Alpine иногда меняет структуру.
