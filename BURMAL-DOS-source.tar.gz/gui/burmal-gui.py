#!/usr/bin/env python3
"""A small green, DOS-inspired BURMAL-DOS graphical shell."""
import os
import platform
import shlex
import subprocess
import threading
import tkinter as tk
from pathlib import Path

BG = "#000900"
PANEL = "#001408"
PANEL_ALT = "#073319"
GREEN = "#39cc64"
BRIGHT = "#aaffaa"
DIM = "#58a76c"
BORDER = "#21833e"
SELECT = "#17602b"
FONT = ("DejaVu Sans Mono", 13)
FONT_SMALL = ("DejaVu Sans Mono", 11)
FONT_TITLE = ("DejaVu Sans Mono", 13, "bold")


class BurmalGUI:
    def __init__(self, root):
        self.root = root
        self.cwd = Path.home()
        self.history = []
        self.history_index = 0
        self.process = None
        self.busy = False
        root.title("BURMAL-DOS")
        root.configure(bg=BG)
        root.minsize(760, 500)
        root.attributes("-fullscreen", True)
        root.bind_all("<F11>", self.toggle_fullscreen)
        root.bind_all("<Escape>", self.leave_fullscreen)
        root.bind_all("<F1>", lambda _e: self.show_help())
        root.bind_all("<F2>", lambda _e: self.show_files())
        root.bind_all("<F4>", lambda _e: self.command_focus())
        root.bind_all("<F10>", lambda _e: self.exit())
        root.protocol("WM_DELETE_WINDOW", self.exit)

        self.build()
        self.write_output("BURMAL-DOS graphical shell\nType 'help' to see commands.\n\n")
        self.refresh_system()
        self.refresh_files()
        root.after(150, self.command_focus)

    def panel(self, parent, title=None):
        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        inner = tk.Frame(outer, bg=PANEL)
        inner.pack(fill="both", expand=True)
        if title:
            bar = tk.Frame(inner, bg=PANEL_ALT, height=30)
            bar.pack(fill="x")
            bar.pack_propagate(False)
            tk.Label(bar, text=f" {title} ", bg=PANEL_ALT, fg=BRIGHT,
                     font=FONT_SMALL, anchor="w").pack(side="left", padx=8, fill="y")
        # Keep the title bar managed by pack, and return a separate content
        # frame so each panel can lay out its children with either pack or grid.
        content = tk.Frame(inner, bg=PANEL)
        content.pack(fill="both", expand=True)
        return outer, content

    def build(self):
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        header = tk.Frame(self.root, bg=PANEL_ALT, height=42)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_propagate(False)
        tk.Label(header, text=" BURMAL-DOS  1.0", bg=PANEL_ALT, fg=BRIGHT,
                 font=FONT_TITLE).pack(side="left", padx=12)
        buttons = tk.Frame(header, bg=PANEL_ALT)
        buttons.pack(side="right", padx=8)
        for key, label, action in (
            ("F1", "HELP", self.show_help),
            ("F2", "FILES", self.show_files),
            ("F4", "COMMAND", self.command_focus),
            ("F10", "EXIT", self.exit),
        ):
            tk.Button(buttons, text=f" {key} {label} ", command=action,
                      bg=PANEL, fg=BRIGHT, activebackground=SELECT,
                      activeforeground=BRIGHT, relief="flat", bd=0,
                      font=FONT_SMALL, padx=4, pady=3,
                      highlightthickness=1, highlightbackground=BORDER,
                      highlightcolor=BRIGHT).pack(side="left", padx=3)

        body = tk.Frame(self.root, bg=BG, padx=8, pady=8)
        body.grid(row=1, column=0, sticky="nsew")
        body.grid_rowconfigure(0, weight=1)
        body.grid_columnconfigure(0, weight=3, minsize=450)
        body.grid_columnconfigure(1, weight=2, minsize=300)

        terminal_outer, terminal = self.panel(body, "COMMAND.COM")
        terminal_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        terminal.grid_rowconfigure(1, weight=1)
        terminal.grid_columnconfigure(0, weight=1)

        toolbar = tk.Frame(terminal, bg=PANEL_ALT, padx=8, pady=4)
        toolbar.grid(row=0, column=0, sticky="ew")
        tk.Label(toolbar, text="DIRECTORY:", bg=PANEL_ALT, fg=BRIGHT,
                 font=FONT_SMALL).pack(side="left")
        self.path_label = tk.Label(toolbar, text=str(self.cwd), bg=PANEL,
                                   fg=BRIGHT, font=FONT_SMALL, anchor="w")
        self.path_label.configure(bg=PANEL_ALT)
        self.path_label.pack(side="left", padx=10, fill="x", expand=True)

        self.output = tk.Text(terminal, bg=BG, fg=GREEN, insertbackground=BRIGHT,
                              selectbackground=SELECT, font=FONT, wrap="word",
                              relief="flat", bd=0, padx=10, pady=8,
                              state="disabled", undo=False)
        self.output.grid(row=1, column=0, sticky="nsew")
        self.output.tag_configure("prompt", foreground=BRIGHT)
        self.output.tag_configure("error", foreground="#ff8b74")
        self.output.tag_configure("dim", foreground=DIM)
        self.output.bind("<Button-1>", lambda _e: self.command_focus())

        cmdbar = tk.Frame(terminal, bg=PANEL_ALT, padx=8, pady=5)
        cmdbar.grid(row=2, column=0, sticky="ew")
        tk.Label(cmdbar, text="C:\\>", bg=PANEL_ALT, fg=BRIGHT,
                 font=FONT).pack(side="left")
        self.command = tk.Entry(cmdbar, bg=PANEL_ALT, fg=BRIGHT,
                                insertbackground=GREEN, selectbackground=SELECT,
                                font=FONT, relief="flat", bd=0,
                                highlightthickness=0)
        self.command.pack(side="left", fill="x", expand=True, padx=(7, 4))
        self.command.bind("<Return>", self.submit_command)
        self.command.bind("<Up>", self.history_up)
        self.command.bind("<Down>", self.history_down)
        self.command.bind("<Button-1>", lambda _e: self.command.focus_force())

        side = tk.Frame(body, bg=BG)
        side.grid(row=0, column=1, sticky="nsew")
        side.grid_rowconfigure(0, weight=1)
        side.grid_rowconfigure(1, weight=2)
        side.grid_columnconfigure(0, weight=1)

        system_outer, system = self.panel(side, "SYSTEM")
        system_outer.grid(row=0, column=0, sticky="nsew", pady=(0, 8))
        self.system_text = tk.Text(system, height=7, bg=PANEL, fg=GREEN,
                                   font=FONT_SMALL, relief="flat", bd=0,
                                   padx=8, pady=6, wrap="word", state="disabled")
        self.system_text.pack(fill="both", expand=True)

        files_outer, files = self.panel(side, "FILES")
        files_outer.grid(row=1, column=0, sticky="nsew")
        self.file_list = tk.Listbox(files, bg=PANEL, fg=BRIGHT,
                                    selectbackground=SELECT, selectforeground=GREEN,
                                    font=FONT_SMALL, relief="flat", bd=0,
                                    highlightthickness=0, activestyle="none")
        self.file_list.pack(fill="both", expand=True, padx=6, pady=6)
        self.file_list.bind("<Double-Button-1>", self.open_selected_file)

        footer = tk.Frame(self.root, bg=PANEL_ALT, height=30)
        footer.grid(row=2, column=0, sticky="ew")
        footer.grid_propagate(False)
        tk.Label(footer, text=" F1 Help   F2 Files   F4 Command   F10 Exit",
                 bg=PANEL_ALT, fg=BRIGHT, font=FONT_SMALL).pack(side="left", padx=8)
        self.status = tk.Label(footer, text="READY ", bg=PANEL_ALT, fg=GREEN,
                               font=FONT_SMALL)
        self.status.pack(side="right", padx=8)

    def write_output(self, text, tag=None):
        self.output.configure(state="normal")
        if tag:
            self.output.insert("end", text, tag)
        else:
            self.output.insert("end", text)
        self.output.see("end")
        self.output.configure(state="disabled")

    def submit_command(self, _event=None):
        if self.busy:
            return "break"
        text = self.command.get().strip()
        self.command.delete(0, "end")
        if not text:
            return "break"
        self.history.append(text)
        self.history_index = len(self.history)
        self.write_output(f"C:\\> {text}\n", "prompt")
        try:
            args = shlex.split(text)
        except ValueError as exc:
            self.write_output(f"Syntax error: {exc}\n", "error")
            return "break"
        cmd = args[0].lower()
        if cmd in ("exit", "quit"):
            self.exit()
        elif cmd == "help":
            self.show_help(in_terminal=True)
        elif cmd == "clear":
            self.output.configure(state="normal")
            self.output.delete("1.0", "end")
            self.output.configure(state="disabled")
        elif cmd == "pwd":
            self.write_output(f"{self.cwd}\n")
        elif cmd == "cd":
            destination = Path(args[1]).expanduser() if len(args) > 1 else Path.home()
            if not destination.is_absolute():
                destination = self.cwd / destination
            try:
                self.cwd = destination.resolve(strict=True)
                if not self.cwd.is_dir():
                    raise NotADirectoryError(str(destination))
                self.path_label.configure(text=str(self.cwd))
                self.refresh_files()
            except OSError as exc:
                self.write_output(f"cd: {exc}\n", "error")
        else:
            self.run_external(text)
        return "break"

    def run_external(self, command):
        try:
            self.process = subprocess.Popen(
                command, shell=True, cwd=str(self.cwd),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, start_new_session=True,
            )
        except OSError as exc:
            self.write_output(f"{exc}\n", "error")
            return
        self.busy = True
        self.command.configure(state="disabled")
        self.status.configure(text="RUNNING ", fg="#d6ef72")
        process = self.process

        def collect():
            try:
                output, _ = process.communicate()
                code = process.returncode
            except Exception as exc:
                output, code = f"Command failed: {exc}\n", 1
            try:
                self.root.after(0, lambda: self.finish_external(output, code))
            except tk.TclError:
                pass

        threading.Thread(target=collect, daemon=True).start()

    def finish_external(self, output, code):
        if output:
            self.write_output(output[-16000:])
            if not output.endswith("\n"):
                self.write_output("\n")
        self.write_output(f"[exit {code}]\n\n", "dim" if code == 0 else "error")
        self.busy = False
        self.process = None
        self.command.configure(state="normal")
        self.command.focus_set()
        self.status.configure(text="READY ", fg=GREEN)
        self.refresh_system()
        self.refresh_files()

    def refresh_system(self):
        try:
            os_name = "BURMAL-DOS"
            for line in Path("/etc/os-release").read_text().splitlines():
                if line.startswith("PRETTY_NAME="):
                    os_name = line.split("=", 1)[1].strip('"')
                    break
            memory = "unknown"
            for line in Path("/proc/meminfo").read_text().splitlines():
                if line.startswith("MemTotal:"):
                    memory = f"{int(line.split()[1]) // 1024} MiB"
                    break
            info = (
                f"OS       {os_name}\n"
                f"Kernel   {platform.release()}\n"
                f"Machine  {platform.machine()}\n"
                f"Memory   {memory}\n"
                f"User     {os.environ.get('USER', 'user')}\n"
            )
        except OSError as exc:
            info = f"System information unavailable\n{exc}"
        self.system_text.configure(state="normal")
        self.system_text.delete("1.0", "end")
        self.system_text.insert("end", info)
        self.system_text.configure(state="disabled")

    def refresh_files(self):
        self.file_list.delete(0, "end")
        try:
            entries = sorted(self.cwd.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower()))
            for item in entries[:100]:
                prefix = "[DIR] " if item.is_dir() else "      "
                self.file_list.insert("end", prefix + item.name)
        except OSError as exc:
            self.file_list.insert("end", str(exc))

    def open_selected_file(self, _event=None):
        selected = self.file_list.curselection()
        if not selected:
            return
        label = self.file_list.get(selected[0])
        name = label[6:]
        path = self.cwd / name
        if path.is_dir():
            self.cwd = path
            self.path_label.configure(text=str(self.cwd))
            self.refresh_files()
            return
        if path.is_file():
            self.command.delete(0, "end")
            self.command.insert(0, f"cat {shlex.quote(str(path))}")
            self.command.focus_set()

    def history_up(self, _event=None):
        if self.history:
            self.history_index = max(0, self.history_index - 1)
            self.command.delete(0, "end")
            self.command.insert(0, self.history[self.history_index])
        return "break"

    def history_down(self, _event=None):
        if self.history:
            self.history_index = min(len(self.history), self.history_index + 1)
            self.command.delete(0, "end")
            if self.history_index < len(self.history):
                self.command.insert(0, self.history[self.history_index])
        return "break"

    def show_help(self, in_terminal=False):
        help_text = (
            "Commands: help, clear, pwd, cd <directory>, ls, fastfetch, "
            "exit\nOther system commands run through the BURMAL-DOS shell."
        )
        self.write_output(help_text + "\n\n", "dim")
        self.command_focus()

    def show_files(self):
        self.refresh_files()
        self.command.focus_set()

    def command_focus(self):
        if self.busy:
            return
        self.root.lift()
        self.command.focus_force()

    def toggle_fullscreen(self, _event=None):
        current = self.root.attributes("-fullscreen") in (True, 1, "1")
        self.root.attributes("-fullscreen", not current)
        return "break"

    def leave_fullscreen(self, _event=None):
        if self.root.attributes("-fullscreen"):
            self.root.attributes("-fullscreen", False)
            return "break"

    def exit(self):
        if self.busy and self.process:
            try:
                self.process.terminate()
            except OSError:
                pass
        self.root.destroy()


if __name__ == "__main__":
    app = tk.Tk()
    BurmalGUI(app)
    app.mainloop()
