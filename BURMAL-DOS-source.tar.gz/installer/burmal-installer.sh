#!/usr/bin/env bash
#
# burmal-installer.sh — консольный (TUI) установщик BURMAL-DOS
# ---------------------------------------------------------------
# Запускается автоматически при загрузке с live-ISO/флешки.
# Управление — стрелками + Enter (через `dialog`), либо цифрами,
# если `dialog` недоступен (запасной текстовый режим).
#
# Пошагово настраивает: раскладку клавиатуры, имя хоста, часовой
# пояс, локаль, сеть, диск и разметку, пользователей, загрузчик —
# и устанавливает базовую систему BURMAL-DOS через apk --root.
#
# ВАЖНО: скрипт предназначен для запуска ВНУТРИ live-окружения
# BURMAL-DOS (root, доступ к реальным блочным устройствам).
# Не запускайте его на своей рабочей машине "как есть".

set -uo pipefail

# Use a known UTF-8 locale for predictable dialog rendering.
[ -r /etc/profile.d/00locale.sh ] && . /etc/profile.d/00locale.sh
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# ---------- Настройки/константы ----------
TARGET=/mnt/target
LOGFILE=/var/log/burmal-install.log
HAVE_DIALOG=0
command -v dialog >/dev/null 2>&1 && HAVE_DIALOG=1
INSTALL_TTY_STATE=""
INSTALL_INPUT_LOCKED=0

C_GREEN="\033[1;32m"
C_RED="\033[1;31m"
C_YELLOW="\033[1;33m"
C_RESET="\033[0m"

log() { echo "[$(date '+%H:%M:%S')] $*" >>"$LOGFILE"; }
die() { echo -e "${C_RED}Error:${C_RESET} $*" >&2; log "FATAL: $*"; exit 1; }

# ---------- Универсальные UI-обёртки (dialog ИЛИ текстовый fallback) ----------

ui_msg() {
    # ui_msg "Заголовок" "Текст"
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        dialog --clear --backtitle "BURMAL-DOS Installer" --ok-label "OK" --cancel-label "Cancel" --title "$1" --msgbox "$2" 12 60
    else
        printf '\n== %s ==\n%s\n' "$1" "$2" > /dev/tty
        read -rp "Press Enter to continue..." _ < /dev/tty
    fi
}

# Show a non-modal status while automated disk/system operations run.
# Unlike --msgbox, --infobox does not wait for Enter or any other key.
ui_status() {
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        dialog --clear --backtitle "BURMAL-DOS Installer" --title "$1" --infobox "$2" 8 68
    else
        printf '\n== %s ==\n%s\n' "$1" "$2" > /dev/tty
    fi
}

lock_installer_input() {
    [[ -r /dev/tty ]] || return 0
    INSTALL_TTY_STATE=$(stty -g < /dev/tty 2>/dev/null) || return 0
    # Hide and buffer input during the non-interactive installation stages.
    # Ctrl-C remains available so an interrupted operation can be diagnosed.
    stty -echo -icanon < /dev/tty 2>/dev/null || return 0
    INSTALL_INPUT_LOCKED=1
    trap restore_installer_input EXIT
}

restore_installer_input() {
    [[ $INSTALL_INPUT_LOCKED -eq 1 ]] || return 0
    # Discard keystrokes entered while commands were running, so they cannot
    # accidentally activate the final confirmation dialog.
    while IFS= read -r -t 0.05 -n 1 _installer_key < /dev/tty; do :; done 2>/dev/null || true
    stty "$INSTALL_TTY_STATE" < /dev/tty 2>/dev/null || true
    INSTALL_INPUT_LOCKED=0
}

ui_input() {
    # ui_input "Заголовок" "Подсказка" "значение_по_умолчанию" -> echo результата
    local title="$1" prompt="$2" default="${3:-}"
    local result
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        result=$(dialog --clear --backtitle "BURMAL-DOS Installer" --ok-label "OK" --cancel-label "Cancel" --title "$title" \
            --inputbox "$prompt" 10 60 "$default" 3>&1 1>&2 2>&3)
    else
        printf '\n== %s ==\n' "$title" > /dev/tty
        read -rp "$prompt [$default]: " result < /dev/tty
        result="${result:-$default}"
    fi
    echo "$result"
}

ui_password() {
    local title="$1" prompt="$2"
    local result
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        result=$(dialog --clear --backtitle "BURMAL-DOS Installer" --ok-label "OK" --cancel-label "Cancel" --title "$title" \
            --insecure --passwordbox "$prompt" 10 60 3>&1 1>&2 2>&3)
    else
        read -rsp "$prompt: " result < /dev/tty; echo > /dev/tty
    fi
    echo "$result"
}

ui_menu() {
    # ui_menu "Заголовок" "Подсказка" "tag1" "описание1" "tag2" "описание2" ... -> echo выбранного tag
    local title="$1" prompt="$2"; shift 2
    local items=("$@")
    local result
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        result=$(dialog --clear --backtitle "BURMAL-DOS Installer" --ok-label "OK" --cancel-label "Cancel" --title "$title" \
            --menu "$prompt" 22 68 14 "${items[@]}" 3>&1 1>&2 2>&3)
    else
        printf '\n== %s ==\n%s\n' "$title" "$prompt" > /dev/tty
        local i=1 tags=()
        while [[ $i -le ${#items[@]} ]]; do
            local tag="${items[$((i-1))]}" desc="${items[$i]}"
        printf '  %d. %s  (%s)\n' "$((i/2+1))" "$desc" "$tag" > /dev/tty
            tags+=("$tag")
            i=$((i+2))
        done
        local choice
        read -rp "Your choice (number): " choice < /dev/tty
        result="${tags[$((choice-1))]}"
    fi
    echo "$result"
}

ui_yesno() {
    local title="$1" prompt="$2"
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        dialog --clear --backtitle "BURMAL-DOS Installer" --yes-label "Yes" --no-label "No" --title "$title" --yesno "$prompt" 10 60
        return $?
    else
        read -rp "$prompt [y/N]: " ans
        [[ "$ans" =~ ^([Yy]|1)$ ]]
        return $?
    fi
}

ui_checklist() {
    # ui_checklist "Заголовок" "Подсказка" "tag1" "desc1" "off" ... -> echo выбранных tag'ов через пробел
    local title="$1" prompt="$2"; shift 2
    if [[ $HAVE_DIALOG -eq 1 ]]; then
        dialog --clear --backtitle "BURMAL-DOS Installer" --ok-label "OK" --cancel-label "Cancel" --title "$title" \
            --checklist "$prompt" 22 68 14 "$@" 3>&1 1>&2 2>&3
    else
        echo "(Text mode: this option is unavailable and will be skipped.)"
    fi
}

# ---------- Приветственный баннер ----------
show_welcome() {
    clear
    printf '%b\n' "${C_GREEN}BURMAL-DOS installation${C_RESET}"
    echo "Setup is starting. Use the arrow keys and Enter."
}

# ---------- Шаг 1: раскладка клавиатуры ----------
step_keyboard() {
    KEYMAP=$(ui_menu "Keyboard layout" "Select a keyboard layout:" \
        us "English (US)" \
        ru "Russian (Cyrillic)" \
        de "German" \
        fr "French (AZERTY)" \
        ua "Ukrainian")
    KEYMAP="${KEYMAP:-us}"
    local keymap_file
    keymap_file=$(find "/usr/share/bkeymaps/$KEYMAP" -type f -name '*.bmap' 2>/dev/null | head -n 1)
    if [[ -n "$keymap_file" ]]; then
        zcat "$keymap_file" | loadkmap 2>/dev/null || true
    else
        loadkeys "$KEYMAP" 2>/dev/null || true
    fi
    log "keymap=$KEYMAP"
}

# ---------- Шаг 2: имя хоста ----------
step_hostname() {
    HOSTNAME=$(ui_input "Computer name" "Enter a network name for this computer:" "burmal-dos")
    [[ -z "$HOSTNAME" ]] && HOSTNAME="burmal-dos"
    [[ "$HOSTNAME" =~ ^[A-Za-z0-9][A-Za-z0-9.-]{0,62}$ ]] || die "Invalid name. Use Latin letters, numbers, dots, and hyphens."
    log "hostname=$HOSTNAME"
}

# ---------- Шаг 3: часовой пояс ----------
step_timezone() {
    REGION=$(ui_menu "Time zone" "Select a region:" \
        Europe "Europe" \
        Asia "Asia" \
        America "America" \
        Africa "Africa" \
        Australia "Australia" \
        UTC "Coordinated Universal Time")
    if [[ "$REGION" == "UTC" ]]; then
        TIMEZONE="UTC"
    else
        local cities
        cities=$(ls "/usr/share/zoneinfo/$REGION" 2>/dev/null | head -n 40)
        if [[ -z "$cities" ]]; then
            TIMEZONE="UTC"
        else
            local menu_items=()
            for c in $cities; do menu_items+=("$c" "$c"); done
            CITY=$(ui_menu "Time zone" "Select a city in $REGION:" "${menu_items[@]}")
            TIMEZONE="$REGION/${CITY:-UTC}"
        fi
    fi
    log "timezone=$TIMEZONE"
}

# ---------- Шаг 4: локаль ----------
step_locale() {
    LOCALE=$(ui_menu "System language" "Select the default system locale:" \
        en_US.UTF-8 "English (US)" \
        ru_RU.UTF-8 "Russian" \
        de_DE.UTF-8 "German" \
        fr_FR.UTF-8 "French" \
        es_ES.UTF-8 "Spanish")
    LOCALE="${LOCALE:-en_US.UTF-8}"
    log "locale=$LOCALE"
}

# ---------- Шаг 5: сеть ----------
step_network() {
    local ifaces
    ifaces=$(ls /sys/class/net | grep -v lo || true)
    [[ -z "$ifaces" ]] && { ui_msg "Network" "No network interfaces were found. Skipping network setup."; return; }

    local menu_items=()
    for i in $ifaces; do menu_items+=("$i" "Network interface $i"); done
    NET_IFACE=$(ui_menu "Network" "Select a network interface:" "${menu_items[@]}")

    NET_MODE=$(ui_menu "Network" "Select an IP configuration for $NET_IFACE:" \
        auto "Automatic (DHCP)" \
        manual "Manual (static IP)")

    if [[ "$NET_MODE" == "manual" ]]; then
        NET_IP=$(ui_input "Network" "IP address (for example, 192.168.1.50/24):" "")
        NET_GW=$(ui_input "Network" "Default gateway:" "")
        NET_DNS=$(ui_input "Network" "DNS server:" "1.1.1.1")
    fi
    log "net_iface=$NET_IFACE net_mode=$NET_MODE ip=${NET_IP:-} gw=${NET_GW:-} dns=${NET_DNS:-}"
}

# ---------- Шаг 6: пользователи ----------
step_users() {
    while true; do
        ROOT_PASS1=$(ui_password "Root password" "Enter the administrator password:")
        ROOT_PASS2=$(ui_password "Root password" "Confirm the root password:")
        [[ "$ROOT_PASS1" == "$ROOT_PASS2" && -n "$ROOT_PASS1" ]] && break
        ui_msg "Error" "The passwords do not match or are empty. Try again."
    done

    USERNAME=$(ui_input "User account" "Enter a username (with sudo privileges):" "user")
    [[ "$USERNAME" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]] || die "Invalid username. Use lowercase letters, numbers, _ or -; the first character must be a letter or _."
    while true; do
        USER_PASS1=$(ui_password "User password" "Enter a password for $USERNAME:")
        USER_PASS2=$(ui_password "User password" "Confirm the password:")
        [[ "$USER_PASS1" == "$USER_PASS2" && -n "$USER_PASS1" ]] && break
        ui_msg "Error" "The passwords do not match or are empty. Try again."
    done
    log "username=$USERNAME"
}

# ---------- Шаг 7: диск и разметка ----------
step_disk() {
    local disks
    disks=$(lsblk -dno NAME,SIZE,TYPE 2>/dev/null | awk '$3=="disk"{print $1" "$2}')
    [[ -z "$disks" ]] && die "No disks were found."

    local menu_items=()
    while read -r name size; do
        menu_items+=("/dev/$name" "$size")
    done <<<"$disks"

    DISK=$(ui_menu "Select disk" "WARNING: all data on the selected disk will be erased!" "${menu_items[@]}")
    [[ -z "$DISK" ]] && die "No disk was selected."

    FS_TYPE=$(ui_menu "Filesystem" "Select a filesystem for the root partition:" \
        ext4 "ext4 (recommended)" \
        btrfs "btrfs" \
        xfs "xfs")

    ui_yesno "Confirm installation" "All data on $DISK will be erased and the disk formatted as $FS_TYPE. Continue?"
    if [[ $? -ne 0 ]]; then
        die "Installation cancelled."
    fi
    log "disk=$DISK fs=$FS_TYPE"
}

# ---------- Шаг 8: применение разметки ----------
do_partition() {
    lock_installer_input
    ui_status "Partitioning disk" "Partitioning $DISK. Please wait..."
    log "partitioning $DISK"

    # Защита от "Error: Partition(s) on $DISK are being used": если это
    # повторный запуск установщика в той же сессии после неудачной
    # попытки, разделы этого диска могли остаться смонтированными или
    # в свопе — ядро откажется отдавать parted'у новую таблицу разделов,
    # пока они заняты. На всякий случай отключаем всё заранее.
    swapoff -a 2>/dev/null || true
    umount -R "$TARGET" 2>/dev/null || true
    for part in "$DISK"*; do
        [ -e "$part" ] && [ "$part" != "$DISK" ] && umount -f "$part" 2>/dev/null
    done
    # LVM/device-mapper поверх этого диска (если есть) — тоже мешает.
    command -v vgchange >/dev/null 2>&1 && vgchange -an 2>/dev/null
    command -v wipefs   >/dev/null 2>&1 && wipefs -a "$DISK" 2>/dev/null
    partprobe "$DISK" 2>/dev/null
    blockdev --rereadpt "$DISK" 2>/dev/null
    sleep 1

    parted -s "$DISK" mklabel gpt \
        mkpart primary 1MiB 2MiB \
        set 1 bios_grub on \
        mkpart ESP fat32 2MiB 514MiB \
        set 2 esp on \
        mkpart primary 514MiB 100% \
        || die "Failed to partition $DISK with parted.

If the error \"Partition(s) ... are being used\" persists:
1) Make sure $DISK is a separate empty disk, not the device used to boot
   this live image (attach the ISO as a CD/DVD device);
2) reboot the virtual machine or computer and restart the installer."

    partprobe "$DISK" 2>/dev/null || true
    sleep 1

    # Определяем имена разделов (учитываем nvme-стиль: /dev/nvme0n1p1)
    # Раздел 1 — BIOS boot (без ФС, только для legacy grub-install),
    # раздел 2 — EFI System Partition, раздел 3 — корень.
    if [[ "$DISK" =~ nvme ]]; then
        BOOT_PART="${DISK}p2"
        ROOT_PART="${DISK}p3"
    else
        BOOT_PART="${DISK}2"
        ROOT_PART="${DISK}3"
    fi

    # Ждём, пока ядро реально создаст device-ноды новых разделов
    # (после wipefs+parted это не всегда мгновенно) — до 5 секунд.
    command -v udevadm >/dev/null 2>&1 && udevadm settle --timeout=5 2>/dev/null
    for _i in 1 2 3 4 5; do
        [ -b "$BOOT_PART" ] && [ -b "$ROOT_PART" ] && break
        partprobe "$DISK" 2>/dev/null
        sleep 1
    done
    [ -b "$BOOT_PART" ] || die "Partition $BOOT_PART was not created on $DISK."
    [ -b "$ROOT_PART" ] || die "Partition $ROOT_PART was not created on $DISK."

    mkfs.vfat -F32 "$BOOT_PART" || die "Failed to create the EFI partition."
    case "$FS_TYPE" in
        ext4)  mkfs.ext4 -F "$ROOT_PART" ;;
        btrfs) mkfs.btrfs -f "$ROOT_PART" ;;
        xfs)   mkfs.xfs -f "$ROOT_PART" ;;
    esac || die "Failed to create the root filesystem."

    mkdir -p "$TARGET"
    mount "$ROOT_PART" "$TARGET" || die "Failed to mount the root filesystem."
    mkdir -p "$TARGET/boot/efi"
    mount "$BOOT_PART" "$TARGET/boot/efi" || die "Failed to mount the EFI partition."
}

# ---------- Шаг 9: установка базовой системы ----------
do_install_base() {
    ui_status "Installing system" "Installing the BURMAL-DOS base system. Please wait..."
    log "installing base system into $TARGET"

    mkdir -p "$TARGET"

    # Live-система по умолчанию смотрит только на локальный репозиторий
    # с самого ISO (/media/cdrom/apks — там нет полного набора пакетов).
    # Для установки явно добавляем настоящие интернет-зеркала Alpine —
    # ветка ДОЛЖНА совпадать с ALPINE_BRANCH из build/build-iso.sh.
    if [ -r /etc/burmal-repositories ]; then
        # This file is generated by the ISO build and contains the exact
        # repository branch used to build the live system.
        . /etc/burmal-repositories
    fi
    APK_REPO_MAIN="${BURMAL_REPO_MAIN:-https://dl-cdn.alpinelinux.org/alpine/edge/main}"
    APK_REPO_COMMUNITY="${BURMAL_REPO_COMMUNITY:-https://dl-cdn.alpinelinux.org/alpine/edge/community}"

    # apk --root проверяет подписи пакетов по ключам ВНУТРИ $TARGET, а не
    # по ключам live-системы. $TARGET только что создан и пуст — без этого
    # шага ЛЮБОЙ пакет (даже официальный) считается UNTRUSTED и установка
    # падает ещё до копирования единого файла.
    mkdir -p "$TARGET"/etc/apk/keys
    cp -a /etc/apk/keys/. "$TARGET"/etc/apk/keys/ 2>/dev/null

    apk --root "$TARGET" --initdb -U \
        -X "$APK_REPO_MAIN" \
        -X "$APK_REPO_COMMUNITY" \
        add alpine-base busybox openrc dialog parted e2fsprogs dosfstools musl-locales musl-locales-lang dhcpcd kbd font-terminus \
            grub grub-bios grub-efi efibootmgr sudo bash shadow \
            linux-lts linux-firmware-none mkinitfs \
        >>"$LOGFILE" 2>&1
    [ $? -eq 0 ] || die "Failed to install base packages. See $LOGFILE for details."

    # Копируем брендинг/dpx/установщик С LIVE-СИСТЕМЫ (это их реальное
    # расположение — см. genapkovl-burmal.sh), поверх того, что только
    # что поставил alpine-base, чтобы установленная система тоже была
    # брендированной, а не голым Alpine.
    cp -f /etc/motd        "$TARGET/etc/motd"        2>/dev/null || true
    cp -f /etc/issue       "$TARGET/etc/issue"        2>/dev/null || true
    cp -f /etc/os-release  "$TARGET/etc/os-release"   2>/dev/null || true
    [ -f /etc/alpine-release ] && cp -f /etc/alpine-release "$TARGET/etc/alpine-release" 2>/dev/null

    # Install the system-wide BURMAL-DOS Fastfetch preset and its ASCII logo.
    # Fastfetch is installed on demand via dpx, so these files can be present
    # before the fastfetch package itself is installed.
    if [ -f /etc/fastfetch/config.jsonc ] && [ -f /usr/share/burmal-dos/fastfetch-logo.txt ]; then
        install -Dm644 /etc/fastfetch/config.jsonc "$TARGET/etc/fastfetch/config.jsonc"
        install -Dm644 /etc/fastfetch/config-stacked.jsonc "$TARGET/etc/fastfetch/config-stacked.jsonc"
        install -Dm644 /etc/fastfetch/config-compact.jsonc "$TARGET/etc/fastfetch/config-compact.jsonc"
        install -Dm644 /usr/share/burmal-dos/fastfetch-logo.txt "$TARGET/usr/share/burmal-dos/fastfetch-logo.txt"
        install -Dm644 /usr/share/burmal-dos/fastfetch-logo-compact.txt "$TARGET/usr/share/burmal-dos/fastfetch-logo-compact.txt"
        install -Dm755 /usr/local/bin/fastfetch "$TARGET/usr/local/bin/fastfetch"
    fi

    # Include an optional Xorg + Tk graphical shell, launched manually with
    # `burmal-gui`; the regular login still starts at the text console.
    apk --root "$TARGET" -U \
        -X "$APK_REPO_MAIN" \
        -X "$APK_REPO_COMMUNITY" \
        add xorg-server xinit xf86-input-libinput xf86-video-vesa eudev mesa-dri-gallium \
            python3 python3-tkinter font-dejavu \
        >>"$LOGFILE" 2>&1 || die "Failed to install graphical interface packages. See $LOGFILE for details."
    install -Dm644 /usr/share/burmal-dos/gui/burmal-gui.py "$TARGET/usr/share/burmal-dos/burmal-gui.py"
    install -Dm755 /usr/share/burmal-dos/gui/burmal-gui "$TARGET/usr/local/bin/burmal-gui"
    install -Dm755 /usr/share/burmal-dos/gui/burmal-gui-session "$TARGET/usr/local/libexec/burmal-gui-session"

    # /etc/apk/repositories на УСТАНОВЛЕННОЙ системе. Флаги -X выше
    # разовые (только на время этого apk add) — apk не запоминает их
    # сам. Без этого файла "sudo dpx install <пакет>" после перезагрузки
    # не будет знать, откуда качать (это и есть баг с fastfetch).
    {
        echo "$APK_REPO_MAIN"
        echo "$APK_REPO_COMMUNITY"
    } > "$TARGET/etc/apk/repositories"

    install -Dm755 /usr/local/bin/dpx "$TARGET/usr/local/bin/dpx" 2>/dev/null || true
    if [ -f /usr/sbin/setup-b-d ]; then
        install -Dm755 /usr/sbin/setup-b-d "$TARGET/usr/sbin/setup-b-d" 2>/dev/null
        ln -sf setup-b-d "$TARGET/usr/sbin/setup-alpine" 2>/dev/null
    fi

    for fs in dev proc sys; do
        mount --bind "/$fs" "$TARGET/$fs"
    done
}

# ---------- Шаг 10: настройка внутри chroot ----------
do_configure_target() {
    ui_status "Configuring system" "Applying system settings and installing the bootloader. Please wait..."
    log "configuring target"

    echo "$HOSTNAME" > "$TARGET/etc/hostname"

    # /etc/fstab — без него загруженное ядро не знает, что монтировать.
    # Используем UUID, а не /dev/sdaN: имена устройств могут меняться
    # между загрузками, UUID — нет.
    ROOT_UUID="$(blkid -s UUID -o value "$ROOT_PART" 2>/dev/null)"
    BOOT_UUID="$(blkid -s UUID -o value "$BOOT_PART" 2>/dev/null)"
    ROOT_BOOT_PARAM="$ROOT_PART"
    [[ -n "$ROOT_UUID" ]] && ROOT_BOOT_PARAM="UUID=$ROOT_UUID"
    {
        if [ -n "$ROOT_UUID" ]; then
            echo "UUID=$ROOT_UUID  /          $FS_TYPE  rw,relatime  0 1"
        else
            echo "$ROOT_PART  /          $FS_TYPE  rw,relatime  0 1"
        fi
        if [ -n "$BOOT_UUID" ]; then
            echo "UUID=$BOOT_UUID  /boot/efi  vfat      rw,relatime  0 2"
        else
            echo "$BOOT_PART  /boot/efi  vfat      rw,relatime  0 2"
        fi
        echo "tmpfs  /tmp  tmpfs  nosuid,nodev  0 0"
    } > "$TARGET/etc/fstab"
    log "fstab written (root_uuid=$ROOT_UUID boot_uuid=$BOOT_UUID)"

    chroot "$TARGET" /bin/sh -e <<CHROOT_EOF >>"$LOGFILE" 2>&1
ln -sf /usr/share/zoneinfo/$TIMEZONE /etc/localtime
echo "$TIMEZONE" > /etc/timezone

adduser -D -s /bin/bash "$USERNAME"
adduser "$USERNAME" wheel 2>/dev/null || true
addgroup -S video 2>/dev/null || true
addgroup -S input 2>/dev/null || true
adduser "$USERNAME" video 2>/dev/null || true
adduser "$USERNAME" input 2>/dev/null || true
echo "%wheel ALL=(ALL) ALL" >> /etc/sudoers

rc-update add sysinit boot 2>/dev/null || true
rc-update add modules boot 2>/dev/null || true
rc-update add networking boot 2>/dev/null || true
rc-update add termencoding sysinit 2>/dev/null || true
rc-update add consolefont boot 2>/dev/null || true
rc-update add udev sysinit 2>/dev/null || true

# initramfs для установленного ядра. Без него GRUB найдёт vmlinuz,
# запустит ядро — и ядро не сможет смонтировать корень (нет драйверов
# ФС/контроллера на старте), т.е. загрузка встанет ещё до init.
KVER="\$(ls /lib/modules 2>/dev/null | head -n 1)"
if [ -n "\$KVER" ]; then
    mkinitfs -F "ata base ide scsi usb virtio mmc nvme ext4 btrfs xfs" -o /boot/initramfs-lts "\$KVER"
else
    echo "WARN: /lib/modules is empty; no kernel was installed and no initramfs was created."
fi
ls -la /boot

# /etc/default/grub — задаём ДО grub-mkconfig. Явно указываем UUID для
# стабильного поиска корневого раздела и rootfstype, чтобы initramfs
# загрузил модуль файловой системы до попытки смонтировать /sysroot.
{
    echo 'GRUB_DISTRIBUTOR="BURMAL-DOS"'
    echo 'GRUB_DISABLE_LINUX_UUID=true'
    echo 'GRUB_CMDLINE_LINUX_DEFAULT="root=$ROOT_BOOT_PARAM rootfstype=$FS_TYPE modules=8139too,virtio_net,ata_piix,sd_mod,ahci,virtio_blk,virtio_pci quiet loglevel=3"'
} >> /etc/default/grub

# Ставим ОБА варианта загрузчика: legacy BIOS (SeaBIOS — это то, что
# по умолчанию использует GNOME Boxes/QEMU) и UEFI. Ни один из двух
# НЕ считается фатальным по отдельности — на конкретной машине рабочим
# окажется только один из них, и это нормально.
BIOS_OK=0
UEFI_OK=0
grub-install --target=i386-pc "$DISK" && BIOS_OK=1 || echo "warn: legacy BIOS grub-install failed"
grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=BURMAL-DOS --removable "$DISK" && UEFI_OK=1 || echo "warn: UEFI grub-install failed"
[ "\$BIOS_OK" -eq 1 ] || [ "\$UEFI_OK" -eq 1 ] || { echo "ERROR: GRUB failed for both BIOS and UEFI"; exit 1; }
grub-mkconfig -o /boot/grub/grub.cfg
echo "--- grub.cfg menuentries ---"
grep -c menuentry /boot/grub/grub.cfg || echo "WARN: no menuentry found in grub.cfg!"
CHROOT_EOF

    # Keep the boot console clear for the BURMAL-DOS login logo. OpenRC still
    # records service output in /var/log/rc.log for troubleshooting.
    printf 'rc_logger="YES"\n' >> "$TARGET/etc/rc.conf"
    if [ -f "$TARGET/etc/inittab" ]; then
        sed -i \
            -e '/openrc sysinit/ s|$| >/dev/null 2>\&1|' \
            -e '/openrc boot/ s|$| >/dev/null 2>\&1|' \
            -e '/openrc default/ s|$| >/dev/null 2>\&1|' \
            "$TARGET/etc/inittab"
    fi

    # Set passwords through stdin so shell characters in them are never
    # interpreted as part of the chroot setup script.
    printf 'root:%s\n' "$ROOT_PASS1" | chroot "$TARGET" chpasswd >>"$LOGFILE" 2>&1 || die "Failed to set the root password."
    printf '%s:%s\n' "$USERNAME" "$USER_PASS1" | chroot "$TARGET" chpasswd >>"$LOGFILE" 2>&1 || die "Failed to set the user password."

    # Keep the choices made in the installer after the first boot.
    mkdir -p "$TARGET/etc/profile.d" "$TARGET/etc/conf.d"
    printf 'export LANG=%q\nexport LC_ALL=%q\n' "$LOCALE" "$LOCALE" > "$TARGET/etc/profile.d/locale.sh"
    printf 'unicode="YES"\n' >> "$TARGET/etc/rc.conf"
    printf 'consolefont="ter-116n.psf.gz"\n' > "$TARGET/etc/conf.d/consolefont"
    printf '8139too\nvirtio_net\n' > "$TARGET/etc/modules"
    local keymap_file
    keymap_file=$(find "/usr/share/bkeymaps/$KEYMAP" -type f -name '*.bmap' 2>/dev/null | head -n 1)
    if [[ -n "$keymap_file" ]]; then
        mkdir -p "$TARGET/etc/keymap" "$TARGET/etc/conf.d"
        gzip -c "$keymap_file" > "$TARGET/etc/keymap/$(basename "$keymap_file").gz"
        printf 'KEYMAP=/etc/keymap/%s.gz\n' "$(basename "$keymap_file")" > "$TARGET/etc/conf.d/keymaps"
        chroot "$TARGET" rc-update add keymaps boot >>"$LOGFILE" 2>&1 || true
    fi

    cat >"$TARGET/etc/network/interfaces" <<'NETCFG'
auto lo
iface lo inet loopback
NETCFG
    if [[ -n "${NET_IFACE:-}" && "${NET_MODE:-}" == "manual" && -n "${NET_IP:-}" ]]; then
        cat >>"$TARGET/etc/network/interfaces" <<EOF
auto $NET_IFACE
iface $NET_IFACE inet static
    address $NET_IP
    gateway $NET_GW
EOF
        printf 'nameserver %s\n' "$NET_DNS" > "$TARGET/etc/resolv.conf"
    else
        # DHCP client discovers network devices at boot. Do not pin the
        # installed system to the live ISO's interface name (often eth0).
        chroot "$TARGET" rc-update add dhcpcd default >>"$LOGFILE" 2>&1 || die "Failed to enable the DHCP client."
    fi
}

# ---------- Шаг 11: завершение ----------
do_finish() {
    # Сохраняем лог установки НА САМ ДИСК, пока он ещё смонтирован —
    # /var/log/burmal-install.log живёт только в live-сессии (tmpfs) и
    # пропадает после перезагрузки. Если что-то пойдёт не так с
    # загрузкой, лог для диагностики иначе достать неоткуда.
    mkdir -p "$TARGET/var/log" 2>/dev/null
    cp -f "$LOGFILE" "$TARGET/var/log/burmal-install.log" 2>/dev/null || true

    # Диагностика на будущее: фактическая разметка и содержимое ESP —
    # если загрузчик не встанет, в логе будет видно, что реально
    # получилось на диске.
    {
        echo "--- parted print $DISK ---"
        parted -s "$DISK" print 2>&1
        echo "--- ls -la /boot (target) ---"
        ls -la "$TARGET/boot" 2>&1
        echo "--- ls -la /boot/efi (target) ---"
        ls -la "$TARGET/boot/efi" 2>&1
        echo "--- /etc/fstab (target) ---"
        cat "$TARGET/etc/fstab" 2>&1
        echo "--- grub.cfg menuentry lines (target) ---"
        grep -n "menuentry\|linux.*vmlinuz\|initrd" "$TARGET/boot/grub/grub.cfg" 2>&1 | head -20
        echo "--- /lib/modules (target) ---"
        ls -la "$TARGET/lib/modules" 2>&1
    } >>"$TARGET/var/log/burmal-install.log" 2>&1

    for fs in dev proc sys; do
        umount -l "$TARGET/$fs" 2>/dev/null || true
    done
    umount -R "$TARGET" 2>/dev/null || true

    restore_installer_input
    trap - EXIT
    ui_msg "Done" "BURMAL-DOS is installed on $DISK.\n\nRemove the installation media and reboot the computer."
    log "install complete"
}

# ---------- Основной сценарий ----------
main() {
    touch "$LOGFILE"
    show_welcome
    step_keyboard
    step_hostname
    step_timezone
    step_locale
    step_network
    step_users
    step_disk
    do_partition
    do_install_base
    do_configure_target
    do_finish
}

main "$@"
